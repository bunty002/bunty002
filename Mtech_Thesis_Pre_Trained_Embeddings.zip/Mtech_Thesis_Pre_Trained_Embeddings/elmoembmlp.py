from embeddingClass import embeddingModel, EpochSaver
import pandas as pd
import numpy as np

from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_recall_fscore_support as score
#test_sent = "will this computer network work"
from sklearn.metrics import classification_report
import joblib
eM = embeddingModel()
eM.load_ELMO_model()

#word_vecs = eM.get_embed_ELMO_sent(test_sent)
#sent_vec = eM.get_embed_ELMO_sent_avg(test_sent)
#print(sent_vec)



def func(sent):
	sentvec=[]
	for x in sent:
		#wordvec.append(eM.get_embed_ELMO_sent(comments))
		sentvec.append(eM.get_embed_ELMO_sent_avg(x) )

	return sentvec
	


		




#eM.load_CBOW_model()


#train_df=pd.read_csv("Base_data+250NotUseful_Code_BaseData_Quering_train.csv")
#test_df = pd.read_csv("Base_data+250NotUseful_Code_BaseData_Quering_test.csv")


#train_df=pd.read_csv("Base_data+CodeCmtsInputs_ChatGPT_Predicted_Usefulness_traindata.csv")
#test_df = pd.read_csv("Base_data+CodeCmtsInputs_ChatGPT_Predicted_Usefulness_testdata.csv")



train_df=pd.read_csv("Basetrain.csv")
test_df = pd.read_csv("Basetest.csv")

#train_df=pd.read_csv("Allcombotrain.csv")
#test_df = pd.read_csv("Allcombotest.csv")


train_df= train_df.sample(frac=1)

test_df= test_df.sample(frac=1)

train_batchsize=100
test_batchsize=100

train_comments=train_df['Comments'][:train_batchsize]
train_code =train_df['Surrounding Code Context'][:train_batchsize]

#train_code =train_df['code'][:train_batchsize]

test_comments=test_df['Comments'][:test_batchsize]
test_code =test_df['Surrounding Code Context'][:test_batchsize]



train_sentveccom=[]
train_sentveccode=[]



test_sentveccom=[]
test_sentveccode=[]


#print('embeddings of comment')
train_sentveccom=func(train_comments)
#print(sentveccom)
#print(len(sentveccom))
#print(len(sentveccom)) 
#print('embeddings of code') 
train_sentveccode=func(train_code)
#print(sentveccode)

test_sentveccom=func(test_comments)

test_sentveccode=func(test_code)

#print(len(train_sentveccode)

train = [[[float(i) for i in train_sentveccom[j]],[float(i) for i in train_sentveccode[j]]] for j in range(0,train_batchsize)]


test=[[[float(i) for i in test_sentveccom[j]],[float(i) for i in test_sentveccode[j]]] for j in range(0,test_batchsize)]

#train,test

trainx = np.array(train)
testx = np.array(test)


trainy=[int(k=='Useful') for k in train_df['Class'][0:train_batchsize]]

testy=[int(k=='Useful') for k in test_df['Class'][0:test_batchsize]]

print(testy)

#classifier = SVC(C=1,kernel='rbf',gamma=0.05, random_state=0)


nsamples, nx, ny = trainx.shape
trainx = trainx.reshape((nsamples,nx*ny))



nsamples, nx, ny = testx.shape
testx = testx.reshape((nsamples,nx*ny))



from sklearn.neural_network import MLPClassifier
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split


'''clf = MLPClassifier(hidden_layer_sizes=(250,100,), activation='relu', *, solver='adam', alpha=0.0001, batch_size='auto', learning_rate='constant', learning_rate_init=0.001, power_t=0.5, max_iter=200, shuffle=True, random_state=None, tol=0.0001, verbose=False, warm_start=False, momentum=0.9, nesterovs_momentum=True, early_stopping=False, validation_fraction=0.1, beta_1=0.9, beta_2=0.999, epsilon=1e-08, n_iter_no_change=10, max_fun=15000).fit(train, trainy)
'''
clf=MLPClassifier(hidden_layer_sizes=(250,100,),activation='relu',max_iter=200,random_state=1).fit(trainx,trainy)
clf.predict(testx)
print(clf.score(testx, testy))






'''

from sklearn.model_selection import GridSearchCV
param_grid = {'C': [0.1, 1, 10, 100, 1000],
              'kernel': ['rbf','linear','sigmoid','poly'],
	      'gamma':[0.1,1,0.01,0.001,0.0001]}
grid = GridSearchCV(SVC(), param_grid)
grid.fit(trainx, trainy)
grid_predictions = grid.predict(testx)


print('Best Parameters',grid.best_params_)
print('Accuracy score:', accuracy_score(testy, grid_predictions)*100)


classifier.fit(trainx,trainy)



#filename = 'model1.sav'
#joblib.dump(classifier, filename)
 
#print("done")




loaded_model1 = joblib.load('model1.sav')
predy = loaded_model1.predict(testx)
acc1=accuracy_score(predy,testy)
print("DataSet: Basetestata.csv")
print ("Model: BaseModel")
print(acc1)
print(classification_report(testy, predy))


loaded_model2 = joblib.load('model2.sav')
predy = loaded_model2.predict(testx)
acc2=accuracy_score(predy,testy)
print("Basetestdata.csv")
print("Model:  Base_data+250NotUseful_Code_BaseData_Quering")
print(acc2)
print(classification_report(testy, predy))



loaded_model3 = joblib.load('model3.sav')
predy = loaded_model3.predict(testx)
acc3=accuracy_score(predy,testy)
print("Basetestdata.csv")
print("Model: Base_data+CodeCmtsInputs_ChatGPT_Predicted_Usefulness ")
print(acc3)
print(classification_report(testy, predy))



loaded_model4 = joblib.load('model4.sav')
predy = loaded_model4.predict(testx)
acc4=accuracy_score(predy,testy)
print("Basetestdata.csv")
print("Model: allCombo")
print(acc4)
print(classification_report(testy, predy))








predy=classifier.predict(testx)
acc =accuracy_score(predy,testy)
print(acc)

#target_names=['useful','not-useful']

#print(classification_report(testy, predy))
#precision, recall, fscore, support = score(testy, predy)

#print('precision: {}'.format(precision))
#print('recall: {}'.format(recall))
#print('fscore: {}'.format(fscore))
#print('support: {}'.format(support))

'''
