'''using bert'''

import torch
import pandas as pd
from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, TensorDataset
from transformers import AdamW, get_linear_schedule_with_warmup

model_name = "bert-base-uncased"
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertForSequenceClassification.from_pretrained(model_name)

data = pd.read_csv('/content/obj3_train.csv')


data = data.sample(frac=1.0, random_state=42) 


code_comments = data[['Surrounding Code Context', 'Comments']]
labels = data['Class']

input_ids = []
attention_masks = []
token_type_ids = []


for code, comment in code_comments.values:
    encoded_dict = tokenizer.encode_plus(
        code, comment,
        add_special_tokens=True,
        max_length=512,  
        pad_to_max_length=True,
        return_attention_mask=True,
        return_token_type_ids=True,
        return_tensors='pt',
    )

    input_ids.append(encoded_dict['input_ids'])
    attention_masks.append(encoded_dict['attention_mask'])
    token_type_ids.append(encoded_dict['token_type_ids'])

labels = torch.tensor(labels)

input_ids = torch.cat(input_ids, dim=0)
attention_masks = torch.cat(attention_masks, dim=0)
token_type_ids = torch.cat(token_type_ids, dim=0)

dataset = TensorDataset(input_ids, attention_masks, token_type_ids, labels)
batch_size = 8
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
num_epochs = 3
# Define optimizer and learning rate scheduler
optimizer = AdamW(model.parameters(), lr=2e-5, eps=1e-8)
scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=0, num_training_steps=len(dataloader) * num_epochs)



for epoch in range(num_epochs):
    model.train()
    for batch in dataloader:
        optimizer.zero_grad()
        input_ids, attention_mask, token_type_ids, labels = batch
        outputs = model(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids, labels=labels)
        loss = outputs.loss
        loss.backward()
        optimizer.step()
        scheduler.step()

# model.eval()

test_data = pd.read_csv('/content/obj3_test.csv')


test_code_comments = test_data[['Surrounding Code Context', 'Comments']]
test_labels = test_data['Class']

test_input_ids = []
test_attention_masks = []
test_token_type_ids = []

for code, comment in test_code_comments.values:
    encoded_dict = tokenizer.encode_plus(
        code, comment,
        add_special_tokens=True,
        max_length=512,  
        pad_to_max_length=True,
        return_attention_mask=True,
        return_token_type_ids=True,
        return_tensors='pt',
    )

    test_input_ids.append(encoded_dict['input_ids'])
    test_attention_masks.append(encoded_dict['attention_mask'])
    test_token_type_ids.append(encoded_dict['token_type_ids'])

test_labels = torch.tensor(test_labels)

test_input_ids = torch.cat(test_input_ids, dim=0)
test_attention_masks = torch.cat(test_attention_masks, dim=0)
test_token_type_ids = torch.cat(test_token_type_ids, dim=0)

test_dataset = TensorDataset(test_input_ids, test_attention_masks, test_token_type_ids, test_labels)
test_dataloader = DataLoader(test_dataset, batch_size=batch_size)

model.eval()
predicted_labels = []
true_labels = []

for batch in test_dataloader:
    with torch.no_grad():
        input_ids, attention_mask, token_type_ids, labels = batch
        outputs = model(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)
        logits = outputs.logits
        predicted_labels.extend(logits.argmax(dim=1).cpu().numpy())
        true_labels.extend(labels.cpu().numpy())


from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

accuracy = accuracy_score(true_labels, predicted_labels)
precision = precision_score(true_labels, predicted_labels)
recall = recall_score(true_labels, predicted_labels)
f1 = f1_score(true_labels, predicted_labels)

print(f"Accuracy: {accuracy}")
print(f"Precision: {precision}")
print(f"Recall: {recall}")
print(f"F1-Score: {f1}")