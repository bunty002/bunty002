
from embeddingClass import embeddingModel, EpochSaver

import pandas as pd
import numpy as np

from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_recall_fscore_support as score
#test_sent = "will this computer network work"
from sklearn.metrics import classification_report
import joblib
eM = embeddingModel()
eM.load_ELMO_model()

#word_vecs = eM.get_embed_ELMO_sent(test_sent)
#sent_vec = eM.get_embed_ELMO_sent_avg(test_sent)
#print(sent_vec)



def func(sent):
        sentvec=[]
        for x in sent:
                #wordvec.append(eM.get_embed_ELMO_sent(comments))
                sentvec.append(eM.get_embed_ELMO_sent_avg(x) )

        return sentvec




#train_df=pd.read_csv("Basetrain.csv")
#test_df = pd.read_csv("Basetest.csv")

train_df=pd.read_csv("Allcombotrain.csv")
test_df = pd.read_csv("Allcombotest.csv")


train_df= train_df.sample(frac=1)

test_df= test_df.sample(frac=1)

train_batchsize=len(train_df)
test_batchsize=len(test_df)

train_comments=train_df['Comments'][:train_batchsize]
train_code =train_df['Surrounding Code Context'][:train_batchsize]

#train_code =train_df['code'][:train_batchsize]

test_comments=test_df['Comments'][:test_batchsize]
test_code =test_df['Surrounding Code Context'][:test_batchsize]



train_sentveccom=[]
train_sentveccode=[]



test_sentveccom=[]
test_sentveccode=[]






train_sentveccom=func(train_comments)
#print(sentveccom)
#print(len(sentveccom))
#print(len(sentveccom))
#print('embeddings of code')
train_sentveccode=func(train_code)
#print(sentveccode)

test_sentveccom=func(test_comments)

test_sentveccode=func(test_code)

#print(len(train_sentveccode)

train = [[[float(i) for i in train_sentveccom[j]],[float(i) for i in train_sentveccode[j]]] for j in range(0,train_batchsize)]


test=[[[float(i) for i in test_sentveccom[j]],[float(i) for i in test_sentveccode[j]]] for j in range(0,test_batchsize)]

#train,test

trainx = np.array(train)
testx = np.array(test)
trainy=[int(k=='Useful') for k in train_df['Class'][0:len(train_df)]]
testy=[int(k=='Useful') for k in test_df['Class'][0:len(test_df)]]



classifier = SVC(C=1,kernel='rbf',gamma=0.05, random_state=0)
nsamples, nx, ny = trainx.shape
trainx = trainx.reshape((nsamples,nx*ny))



nsamples, nx, ny = testx.shape
testx = testx.reshape((nsamples,nx*ny))






classifier.fit(trainx,trainy)



filename = 'model4.sav'
joblib.dump(classifier, filename)

print("done")

predy=classifier.predict(testx)
acc =accuracy_score(predy,testy)
print(acc)

#target_names=['useful','not-useful']

print(classification_report(testy, predy))

